# Moderna mRNA Vaccine Clinical Safety & Dosage Intelligence Platform

**Internship / VIP Project** | Intermediate Level | 4-Week Duration  
**Case Study:** Applied AI — Machine Learning, Deep Learning & Generative AI  
**Reference:** Moderna public mRNA therapeutics work (educational case study)

---

## Project Overview

This project builds an end-to-end AI platform that supports clinical decision-making for mRNA vaccine safety and dosage. You act as an AI engineer supporting a workflow similar to those used in regulated biotech environments.

The system combines three layers of modern AI engineering:

1. **Classical Predictive ML** — Risk classification from patient clinical & biomarker data  
2. **Deep Learning (Self-Attention)** — From-scratch Transformer attention applied to genetic sequence concepts  
3. **Generative AI (RAG + Structured LLM Output)** — Retrieval-Augmented Generation over regulatory guidelines + schema-validated clinical safety reports

Each module’s output feeds the next, mirroring real production AI systems in healthcare.

---

## What You Will Build

| Component | Description |
|-----------|-------------|
| Cleaned Dataset | Validated tabular patient clinical & biomarker records |
| Risk Classifier | Supervised model predicting adverse-reaction risk band |
| Self-Attention Module | From-scratch implementation of Transformer self-attention |
| RAG Pipeline | Private retrieval system over regulatory guideline documents |
| LLM Report Generator | Structured, schema-validated clinical safety summary |
| Dashboard & Report | Results visualization + portfolio-ready technical write-up |

---

## Project Structure

```
mRNA_VIP_Project/
│
├── README.md                          # This file
├── requirements.txt                   # Python dependencies
├── .gitignore                         # Git ignore rules
│
├── data/                              # Datasets
│   └── patient_records.csv            # Raw patient clinical data (500 records)
│
├── docs/                              # Source documents
│   ├── mRNA_VIP_Project_PRD_Handout.docx
│   └── Moderna_mRNA_Safety_Guidelines.docx   # RAG knowledge base source
│
├── src/                               # Source code (by week)
│   ├── week1_ml/                      # Traditional ML & tabular processing
│   ├── week2_attention/               # Self-attention from scratch
│   ├── week3_rag/                     # RAG over regulatory guidelines
│   └── week4_report/                  # LLM report generation & dashboard
│
├── notebooks/                         # Jupyter notebooks for exploration
├── reports/                           # Final reports, figures, dashboards
└── config/                            # Configuration files, prompts, schemas
```

---

## Four-Week Timeline

### Week 1 — Traditional ML & Tabular Data Processing
- Clean, normalize, and explore `patient_records.csv`
- Handle missing values, encode categorical features
- Train & evaluate a classification model (risk band prediction)
- Produce confusion matrix, classification report, feature importance

### Week 2 — Deep Learning Mathematics: Self-Attention
- Implement multi-head self-attention from first principles (NumPy / PyTorch)
- Apply the mechanism to sequence-style (genetic / clinical) data
- Visualize attention weights and interpret results

### Week 3 — Retrieval-Augmented Generation over Regulatory Guidelines
- Ingest & chunk `Moderna_mRNA_Safety_Guidelines.docx`
- Embed chunks and store in a local vector database
- Build a RAG pipeline that answers natural-language questions grounded in the source document
- Cover storage, dosing, contraindications, and reporting rules

### Week 4 — LLM Report Generation, Dashboard & Portfolio Write-up
- Combine risk prediction + retrieved regulatory facts
- Generate structured, Pydantic/LangChain schema-validated clinical safety summaries
- Build a results dashboard
- Write the final project report

---

## Dataset

**File:** `data/patient_records.csv`  
**Records:** 500 patients  

| Column | Description |
|--------|-------------|
| `Patient_ID` | Unique identifier |
| `Age` | Patient age |
| `Biomarker_Level` | Inflammatory biomarker value |
| `Pre_Existing_Conditions` | Count of relevant pre-existing conditions |
| `Vaccine_Dose_mcg` | Administered dose in micrograms |
| `Prior_Reaction_History` | Previous reaction severity (None / Mild / Moderate) |
| `Reaction_Score` | Target variable (0 = low risk, 1 = elevated risk) |

---

## Environment Setup

```bash
# Clone / extract the project
cd mRNA_VIP_Project

# Create virtual environment
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
```

Recommended packages (see `requirements.txt`):
- pandas, numpy, scikit-learn
- torch / pytorch
- langchain, chromadb (or faiss), sentence-transformers
- pydantic, openai / anthropic (or local LLM)
- matplotlib, seaborn, streamlit / gradio (optional dashboard)

---

## Learning Objectives

By the end of this project you will be able to:

- Perform structured data cleaning, normalization, and EDA on clinical-style tabular data
- Train, evaluate, and interpret classical supervised classifiers
- Explain and implement Transformer self-attention mathematics from first principles
- Design a document ingestion → chunking → embedding → vector-store pipeline
- Build a RAG system that grounds LLM answers in retrieved source text
- Enforce structured, schema-validated JSON output from an LLM with hallucination guardrails
- Communicate multi-stage AI system results through visualizations and a technical report

---

## Evaluation Rubric (Summary)

| Criterion | Weight |
|-----------|--------|
| Data quality & ML model performance | 20% |
| Correctness of self-attention implementation | 20% |
| RAG retrieval quality & grounding | 20% |
| Structured LLM report generation | 20% |
| Code quality, documentation & final report | 20% |

---

## Notes

- This is an **educational case study** referencing Moderna’s public mRNA work. It is **not** an official Moderna product or clinical tool.
- Treat all patient data as synthetic / de-identified for learning purposes.
- Always ground clinical-style recommendations in the retrieved regulatory text; never invent dosage or safety guidance.

---

## Author

Internship / VIP Project submission  
Organized project structure with source materials and weekly module folders.

---

*Built as an end-to-end Applied AI case study covering Machine Learning → Deep Learning → Generative AI.*
